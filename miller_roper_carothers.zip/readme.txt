Features implemented on the 3/30 submission:

Feature 3: categorizeable ticket class
--> tickets can have various categories they are assigned to so that tickets are more organized
--> relevant functions: addTicket

Feature 4: ticket priority
--> tickets are automatically sorted to yield most voted tickets being the highest priority ("top" tickets)
--> relevant functions: updatePriority